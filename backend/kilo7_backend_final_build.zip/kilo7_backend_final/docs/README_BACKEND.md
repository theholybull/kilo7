# KILO7 Backend (Phase 1–2) — Contract-Correct Build

This package implements the Phase 1–2 backend nodes for KILO .7:

- MQTT bridge (untrusted cmd/ui/phone -> ROS JSON; ROS truth -> MQTT truth)
- Safety Gate stub (single stop authority, publishes `kilo/state/safety`)
- Control PWM (pigpio 60Hz, TTL + lock semantics, publishes `kilo/state/control`)
- Relay kill stub (fail-loud, publishes relay truth via ROS and into control truth)

## Deployment assumptions (REQUIRED)

This package does not create system users or `/opt` layout automatically.

You MUST provide:
- A Linux user named: `kilo`
- Install root: `/opt/kilo7` (owned by `kilo`)
- ROS workspace at: `/opt/kilo7/robot/ros_ws`

Systemd units are written against those assumptions unless overridden via:
- `/etc/default/kilo7`
- `/opt/kilo7/kilo7-backend.env`

## PWM mode

This build is configured for `pwm.mode=pigpio`.

REQUIRED MINIMUM continuity for pigpio:
- install `pigpio` + `python3-pigpio`
- enable `pigpiod.service` at boot
- `kilo7-control.service` orders After/Wants `pigpiod.service`

## Install deps (Pi)

```bash
sudo ./tools/install_pi_deps.sh
```

## Build workspace

From `/opt/kilo7`:

```bash
cd /opt/kilo7/robot/ros_ws
colcon build
source install/setup.bash
```

## Run nodes (manual)

```bash
source /opt/kilo7/robot/ros_ws/install/setup.bash
ros2 run kilo_core mqtt_bridge
ros2 run kilo_core safety_gate
ros2 run kilo_core relay_kill
ros2 run kilo_core control_pwm
```

## Systemd

Systemd unit files are located in:
`robot/ros_ws/src/kilo_core/systemd/`

Copy them into `/etc/systemd/system/` and enable as needed.
